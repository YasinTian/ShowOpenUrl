//
//  FLEXSetExplorerViewController.h
//  Flipboard
//
//  Created by Ryan Olson on 5/16/14.
//  Copyright (c) 2014 Flipboard. All rights reserved.
//

#import "FLEXObjectExplorerViewController.h"

@interface FLEXSetExplorerViewController : FLEXObjectExplorerViewController

@end
